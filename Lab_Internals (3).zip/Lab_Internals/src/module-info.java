/**
 * 
 */
/**
 * @author MSIS
 *
 */
module Lab_Internals {
	requires java.sql;
}